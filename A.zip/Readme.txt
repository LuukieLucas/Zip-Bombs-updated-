Unzip the file with Winzip.
Password: AAAAAAAA
The rest is without password and can be unzipped with every version of windows.
Select the zip file and right-click on it.
Select the option "extract all".
Repeat.